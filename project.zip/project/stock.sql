CREATE TABLE IF NOT EXISTS `stock`(
    `PRODUCT_ID` int(10) NOT NULL,
    `CATEGORY_NAME` varchar(250) NOT NULL,
    `PRODUCT_NAME` varchar(50) NOT NULL,
    `QUANTITY` int(30) NOT NULL,
      `UNIT` varchar(50) NOT NULL,
    `UNIT_PRICE` int(10) NOT NULL    
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
