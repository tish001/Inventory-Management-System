CREATE TABLE IF NOT EXISTS `product`(
    `PRODUCT_ID` int(10) NOT NULL,
    `CATEGORY_NAME` varchar(250) NOT NULL,
    `PRODUCT_NAME` varchar(50) NOT NULL,
    `DESCRIPTION` varchar(800) NOT NULL,
    `QUANTITY` int(30) NOT NULL,
    `UNIT` varchar(50) NOT NULL,
    `UNIT_PRICE` int(10) NOT NULL,
    PRIMARY KEY (`PRODUCT_ID`),
     FOREIGN KEY (`CATEGORY_NAME`) REFERENCES `category`(`CATEGORY_NAME`)

) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `product`
 (`PRODUCT_ID`,`CATEGORY_NAME`,`PRODUCT_NAME`,`DESCRIPTION`,`QUANTITY`,`UNIT`,`UNIT_PRICE`) VALUES
(101,'Fruit', 'Apple','Green apples provide a huge range of health and beauty benefits, especially when compared to red apples',5,'kg',100),
(102,'Fruit', 'Orange','Nutritional facts/Ingredients:Vitamin A 4% Vitamin C 88%,Calcium 4% Iron 0%,Vitamin D 0% Vitamin B-6 5%,Cobalamin 0% Magnesium 2% ',5,'kg',100);

