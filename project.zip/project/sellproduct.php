<?php
	include('connection.php');
	if(isset($_COOKIE['USER_NAME'])) $user = $_COOKIE['USER_NAME'];
	if(isset($_SESSION['USER_NAME'])) $user = $_SESSION['USER_NAME'];
	if(!isset($user))
	{
		echo"<script>window.open('login.php?mes=Access Denied..','_self');</script>";
		
	}

?>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

    <style>
        th {
            width: 8%;
            font-size: small;
            font-weight: bolder;
        }


        b {
            color: blueviolet;
            font-weight: lighter;
        }

        .b1 {
            color: blueviolet;
            font-weight: bold;
        }

        .heading {
            font-weight: bolder;
            color: blueviolet;
        }

        p {
            font-weight: bolder;
        }

        .success1 {

            color: green;
            font-weight: bolder;
            text-align: center;
            margin-bottom: 10px;

        }

        .position {
            float: right;
            margin-top: 10px;
            margin-right: 25px;

        }

        .position1 {
            float: right;
            margin-top: 10px;
            margin-right: 20px;

        }

        .position3 {
            float: right;
            margin-top: 5px;
            margin-right: 20px;

        }

        .selectdeg {
            width: 200px;
            height: 27px;

        }

        .modal-dialog {
            width: auto;
            max-width: 900px;
        }

        .error {
            color: #FF0000;
            font-size: medium;
            font-weight: bolder;
            line-height: 30px;
            border-radius: 5px;
            height: 30px;

            text-align: center;
            margin-bottom: 10px;
        }

        span {
            font-weight: bolder;
        }

        input {
            width: 90%;
            float: center;

        }

        input.larger {
            width: 40px;
            height: 30px;

        }

        .bord {
            border-width: 0px;
            border: none;
            background-color: whitesmoke;
            font-weight: bold;
        }
    </style>
</head>


<body>

<a href="logout.php"><button class="btn btn-danger btn-md position">
            <span class="glyphicon glyphicon-log-out "></span><b style="font-weight: bolder;color:white;">Logout</b></button></a>

    
    <a href="admin.php"><button class="btn btn-primary btn-md position1">
            <span class="glyphicon glyphicon-home"></span><b style="font-weight: bolder;color:white;">Home</b></button></a>
            <a href="<?php $_SERVER['PHP_SELF']; ?>"><button class="btn btn-success btn-md position">
            <span class="glyphicon glyphicon-refresh "></span><b style="font-weight: bolder;color:white;">Refresh</b></button></a>

    <br />&nbsp;

    <div class="container-fluid">
        </br>
        <form role="form" method="post" action="<?php echo $_SERVER["PHP_SELF"]; ?>">
            <?php $now = new DateTime();
            echo '<span class=" glyphicon glyphicon-time position3"  style="color:teal;font-weight:bolder;font-size:1.2em;"> SELL DATE: ' . $now->format('d-m-Y') . '</span>'; ?>
            </br>&nbsp;

            <table class="table table-striped">
                <tr>
                    <td>
                        <p>CATEGORY NAME<p>




                                <select name="cname" id="cname" required class="selectdeg">

                                    <?php

                                    $sl = "SELECT DISTINCT(CATEGORY_NAME) FROM stock where QUANTITY>0";
                                    $r = $conn->query($sl);


                                    if ($r->num_rows > 0) {

                                        echo "<option value=''>Select Category</option>";
                                        while ($ro = $r->fetch_assoc()) {
                                         

                                                echo "<option value='{$ro["CATEGORY_NAME"]}'>{$ro["CATEGORY_NAME"]} </option>";
                                            
                                        }
                                    }

                                    ?>

                                </select>
                                <span class="error">*</span>
                    </td>

                </tr>
                <tr>
                    <td>
                        <button type="submit" class="btn btn-success" value="submit" name="submit">submit</button>

                </tr>
                </td>
            </table>

        </form>
    </div>
    <form role="form" method="post" action="<?php echo $_SERVER["PHP_SELF"]; ?>">


        <div class="container-fluid">
            <table class="table table-striped">
                <thead>
                    <tr class="success">
                    <tr class="success">
                        <th>PRODUCT ID</th>
                        <th>CATEGORY NAME</th>
                        <th>PRODUCT NAME</th>
                        <th>QUANTITY</th>
                        <th>UNIT</th>
                        <th>IMAGE</th>
                        <th>UNIT PRICE</br>(purchased)</th>
                        <th>UNIT PRICE</br>(selling)</th>
                        <th>SELL </th>


                    </tr>
                <tbody>

                    <?php



                    if (isset($_POST["submit"])) {

                        $c = $_POST["cname"];

                        $sql4 = "SELECT PRODUCT_ID,CATEGORY_NAME,PRODUCT_NAME,UNIT,UNIT_PRICE,QUANTITY as q FROM stock  where CATEGORY_NAME='$c' and QUANTITY>0
                      GROUP BY PRODUCT_ID  ASC";
                        $result = mysqli_query($conn, $sql4);


                        if ($result->num_rows > 0) {
                            // output data of each row

                            $i = 0;
                            while ($row = $result->fetch_assoc()) {
                                $image_id = $row["PRODUCT_ID"];
                                $UNIT_PRICE = $row["UNIT_PRICE"];


                                    $setprice = ceil(($UNIT_PRICE + (($UNIT_PRICE * 3) / 100)));
                                    // echo $image_id;

                    ?>
                                    </tr>
                <tbody>
                    <tr>
                
                        <td><input type="text" class="bord" readonly value="<?php echo $row["PRODUCT_ID"]; ?>" name="pid[]" id="pid" ></td>
                        <td><input type="text" value="<?php echo $row["CATEGORY_NAME"]; ?>" name="cname[]" class="bord"></td>
                        <td><input type="text" readonly value="<?php echo $row["PRODUCT_NAME"]; ?>" name="pname[]" class="bord"></td>

                        <td> <input type="number" style="font-weight: bold;color:teal" required min="1" max="<?php echo $row["q"]; ?>" value="<?php echo $row['q']; ?>" name="quantity[]">
                            <span class="error">*</span></td>
                        <td><input type="text" readonly value="<?php echo $row["UNIT"]; ?>" name="u[]" class="bord"></td>
                        <td><img src="img/<?php echo $image_id; ?>.jpg" width="100px" height="100px">
                        <td><input type="text" readonly value="<?php echo $row["UNIT_PRICE"]; ?>" name="u_p[]" class="bord"></td>
                        <td><input type="number" style="font-weight: bold;color:teal" required min="1" max="5000" value="<?php echo $setprice ?>" name="sell_price[]"></td>
                       
                        </td>
                        <td>
                     
                            <input type="radio" class="larger" name="status[<?php echo $i; ?>]" value="status">
                            <spanstyle="color:red;font-size:2.1em;"></span>
                                <input type="hidden" value="<?php echo $row["q"]; ?>" name="oldq[]" id="oldq">
                        </td>

                    </tr>


        <?php
                                    $i++;
                                
                            }
                        } else {
                            echo "No record Found";
                        }
        ?> <tr>
            <td colspan="9">
                </br>
                <button type="submit" name="submit1" class="btn btn-danger btn-lg" style="float:right;"><span class="glyphicon glyphicon-shopping-cart"></span>SELL CONFIRM</button>
        </tr>
        </td>
    <?php

                    }


    ?>



                </tbody>
                </thead>
            </table>
        </div>


        <?php
        if (isset($_POST['submit1'])) {
            if (!empty($_POST['status'])) {
                foreach ($_POST['status'] as $id => $pid) {

                    $ID = $_POST['pid'][$id];
                    $C = $_POST['cname'][$id];
                    $P = $_POST['pname'][$id];
                    $purchase_q = $_POST['oldq'][$id];

                    $UP = $_POST['u_p'][$id];
                    $sellprice1 = $_POST['sell_price'][$id];
                    //echo $setprice;
                    //echo'</br>'; 
                    $Q = $_POST['quantity'][$id];
                  
                    //echo $pur_price;
                    //echo "</br>";

                    //echo $setprice;
                    $tsell = $Q * $sellprice1;
                    //echo "$tsell";
                    //echo "</br>";
                    $t =   $now->format('Y-m-d');
                    $price = (($sellprice1 - $UP)*$Q);

                    if ($price > 0) {
                        $profit = $price;
                        //  echo"profut";
                        // echo $profit;
                        $loss = 0;
                    } elseif ($price < 0) {
                        $loss = abs($price);
                        //  echo"loss";
                        // echo $loss;
                        $profit = 0;
                    } else {
                        $profit = 0;
                        $loss = 0;
                        // echo"loss and profut";
                        // echo $profit;

                        // echo $loss;


                    }


                    $p = $profit;


                    $l = $loss;





                    $sql5 = "INSERT INTO sell(PRODUCT_ID,CATEGORY_NAME,PRODUCT_NAME,QUANTITY,BUYING_PRICE,UNIT_SELL_PRICE,TOTAL_SELL_PRICE,SELL_DATE,PROFIT,LOSS) 
                        VALUES ('$ID','$C','$P','$Q','$UP','$sellprice1','$tsell','$t','$p','$l')";

                    if (mysqli_query($conn, $sql5)) {
                        $newq = $purchase_q - $Q;
                      //  echo $purchase_q;
                       // echo $ID;

                     $sql2 = "UPDATE stock SET QUANTITY='$newq' where PRODUCT_ID='$ID'";
                     if (mysqli_query($conn, $sql2)) {
                           
                        /*  if($newq==0){
                         $s= "DELETE  FROM `stock` WHERE PRODUCT_ID = '$ID'";

                      //  echo  '<div class="success1">'.$Q .'of'. $P.' Has been Sold successfully!</div>';
                      $result3 = $conn->query($s);
                           echo "this product is out of stock";
                        }*/ 
                         echo  '<div class="success1">' . $Q . 'of' . $P . ' Has been sold successfully!</div>';
                        
                 //   }



                    //       $sql2 ="UPDATE purchase SET QUANTITY='$Q' where PRODUCT_ID='$ID'";*/



                    }

                }
            }
        }

             else {
                echo "<div class='error'>PLEASE SELECT A PRODUCT!</div>";
            }
        }



        ?>
        </table>
    </form>
    <?php mysqli_close($conn);?>
</html>