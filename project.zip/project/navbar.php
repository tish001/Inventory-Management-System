<?php ?>
<html>

<div class="navbar">

			<ul class="list">
				<b style="color:gray;float:left;line-height:50px;margin-left:15px;font-family:Cooper Black;">
				INVENTORY MANAGEMENT SYSTEM</b>
			<?php
				
					echo'

						<li style><a href="admin.php"><b style="color:black">Home</b></a></li>
						<li class="lab1"><a href="logout.php"><b style="color:black">Logout</b></a></li>
							';
				
				
			?>

			</ul>
		</div>
</html>
