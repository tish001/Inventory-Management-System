<?php

include('connection.php');

if(!isset($_SESSION["USER_NAME"]))
{
    echo"<script>window.open('login.php?mes=Access Denied..','_self');</script>";
    
}
$var = $_GET['status_id'];
$sql="select * from product where PRODUCT_ID='$var'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  

  while($row = $result->fetch_assoc()) {

?>
<html>
    <head>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    

    </head>


    <?php

   if (isset($_POST["edit"])) {
       $pid=$_POST["pid"];
       $des1= $_POST["descript1"];
       $u_p1= $_POST["unit_price1"];
     

            $sql2 ="UPDATE product SET DESCRIPTION='$des1',UNIT_PRICE='$u_p1' where PRODUCT_ID='$pid'";


            if (mysqli_query($conn,$sql2)) { 
             // echo "<script>window.open('product.php','_self');</script>";
        
          
              echo '<script type="text/javascript">'; 
              echo 'alert(" record updated successfully");'; 
              echo 'window.location.href = "product.php";';
              echo '</script>';
            }
             else{
              echo '<script type="text/javascript">'; 
              echo 'alert("update failed");'; 
              echo 'window.location.href = "updatep.php";';
              echo '</script>';
             }
          }
  
        

   ?>
    <body>
    <form role="form" method="post">
    <table class="table table-striped">
    <tr><td><p>PRODUCT ID</p> </td></tr>
    <tr><td>    <input type="text" name="pid"  readonly value="<?php echo $row['PRODUCT_ID'];?>">   </tr></td>  
 
    <tr><td><p>PRODUCT NAME</p> </td></tr>
    <tr><td>    <input type="text" name="pname"  readonly value="<?php echo $row['PRODUCT_NAME'];?>">   </tr></td>  
        <tr><td><p>DESCRIPTION</p> </td></tr>
     
        <tr><td><textarea rows="10" cols="80"  name="descript1" ><?php echo $row["DESCRIPTION"];?> </textarea>  </td></tr>
  

      <tr><td><p>UNIT PRICE</p> </td></tr>
      <tr><td>  <input type="text" value="<?php echo $row["UNIT_PRICE"];?>" name="unit_price1" > </td></tr>
  <tr><td>    <button type="submit" class="btn btn-default"  name="edit" value="edit" >Edit</button></tr></td>

</table>



  </form>
  </body>
  </html>
  <?php  }

}
?>




    
 

