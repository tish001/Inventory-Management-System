<?php
	include('connection.php');
	if(isset($_COOKIE['USER_NAME'])) $user = $_COOKIE['USER_NAME'];
	if(isset($_SESSION['USER_NAME'])) $user = $_SESSION['USER_NAME'];
	if(!isset($user))
	{
		echo"<script>window.open('login.php?mes=Access Denied..','_self');</script>";
		
	}

?>

<!DOCTYPE html>
<html>
	<head>
		<title>Inventory Management System</title>
		<link rel="stylesheet" type="text/css" href="style1.css">
		<style>
.bodypic
{
	background-image: url('img/home.jpg');
position: fixed;

  background-size: cover;
  height: 100%;
 
}
.hr1{
	
height: 1px;
background-color: black;
border: none;
}
		</style>
	</head>

	<body class="bodypic">
<div class="containter-fluid">
		<?php include"navbar.php";?><br>
		</br></br></br></br></br>&nbsp;
			
			<div id="section">
		
				<?php include"sidebar.php";?>
</div>
				<div class="content3">
				</br></br>
				<?php
				
				
				$sql = "select * from admin";
				$result = mysqli_query($conn, $sql);
				if ($result->num_rows > 0) {
					while ($row = $result->fetch_assoc()) {
				
$r=$row["FIRST_NAME"];

			   
				
				?>
				<marquee width="60%" direction="left" height="100px">
				<h3 class="text">Welcome <?php echo $r." ".$row["LAST_NAME"]; ?></h3><br><hr class="hr1"><br>
			  


</marquee>
				
					<img src="img/admin.jpg" class="imgs">
					<p class="para">
						<label class="text1">First Name: <b class="text1"> <?php echo $row["FIRST_NAME"];?></b></label></br>
						<label class="text1">Last Name: <b class="text1"> <?php echo $row["LAST_NAME"];?></b></label></br>
						<label class="text1">Email: <b class="text1"> <?php echo $row["EMAIL"];?></b></label></br>
						<label class="text1">User Type: <b class="text1"> <?php echo $row["USER_TYPE"];?></b></label>
						 <?php } }?>
					</p>
					
				
				</div>

			</div>
					</div>
	</body>

</html>
<?php mysqli_close($conn);?>