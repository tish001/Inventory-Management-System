<?php
	include('connection.php');
	if(isset($_COOKIE['USER_NAME'])) $user = $_COOKIE['USER_NAME'];
	if(isset($_SESSION['USER_NAME'])) $user = $_SESSION['USER_NAME'];
	if(!isset($user))
	{
		echo"<script>window.open('login.php?mes=Access Denied..','_self');</script>";
		
	}

?>

<!DOCTYPE html>
<html>
	<head>
		<title>Inventory Management System</title>
		<link rel="stylesheet" type="text/css" href="style1.css">
		<style>
.bodypic
{
    background-image: url('img/manage.jpg');

position: fixed;

  background-size: cover;
  height: 100%;
 
}
		</style>
	</head>

	<body class="bodypic">
<div class="containter-fluid">
		<?php include"navbar.php";?><br>
		</br></br></br>&nbsp;
			
			<h1 align="center">INVENTORY MANAGEMENT SYSTEM</h1>
					<p class="para" style="color:black;font-weight:bold;float:right;margin-top:60px">
                    Having an inventory management system for any shop can be beneficial. 
                    By using this type of system, the products of an inventory can easily be managed.
                     How much products are there in the inventory, what is the report of sells, how much products to be bought - 
                     all can be accomplished by just interacting with the system from anywhere. Buying and selling products can also be
                      managed. The aim of this project is to develop such an inventory management system that
                       can provide all the functionality of a grocery shop. In this system, only an admin can login by providing
                        valid credentials. The admin can add, delete, update various products. He/she can also buy and sell products. 
                        The functionality of managing the stock is also there in this inventory management system. Additionally, 
                        three types of reports are generated from the system automatically. 
                        
					</p>
					
				
				</div>

			
	</body>

</html>
<?php mysqli_close($conn);?>