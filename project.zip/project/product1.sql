CREATE TABLE IF NOT EXISTS `product`(
    `PRODUCT_ID` int(10) NOT NULL,
    `CATEGORY_NAME` varchar(250) NOT NULL,
    `PRODUCT_NAME` varchar(50) NOT NULL,
    `DESCRIPTION` varchar(800) NOT NULL,
    `UNIT` varchar(50) NOT NULL,
    `UNIT_PRICE` int(10) NOT NULL,
    PRIMARY KEY (`PRODUCT_ID`),
     FOREIGN KEY (`CATEGORY_NAME`) REFERENCES `category`(`CATEGORY_NAME`)

) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `product`
(`PRODUCT_ID`,`CATEGORY_NAME`,`PRODUCT_NAME`,`DESCRIPTION`,`UNIT`,`UNIT_PRICE`) VALUES
(101,'Fruit', 'Apple','Green apples provide a huge range of health and beauty benefits, especially when compared to red apples','Kg',100),
(102,'Fruit', 'Orange','Nutritional facts/Ingredients:Vitamin A 4% Vitamin C 88%,Calcium 4% Iron 0%,Vitamin D 0% Vitamin B-6 5%,Cobalamin 0% Magnesium 2% ','Kg',100),

(103,'Fruit', 'Mango','Amrapali from Rajshahi','Kg',100),
(105,'Fruit', 'Cocunut','large in size and sweet meat','Pcs',100),
(106,'Fruit', 'Dragonfruit','large in size and sweet meat','Kg',60),
(107,'Fish', 'Hilsha','large in size, Padma Hilsha','Kg',1000),
(108,'Fish', 'Rui','large in size','Kg',400),
(109,'Fish', ' Lobstars ','large in size','Kg',800),

(110,'Meat', 'Beef','fresh and full  of Protein','Kg',600),
(111,'Meat', 'Chicken ','fresh and full  of Protein','Kg',140),
(112,'Meat', 'Mutton','fresh and full  of Protein','Kg',700),
(113,'Dairy', 'Cadbury Dairy Milk ','full of NUTS  and full  of Protein','Pcs',420),
(114,'Dairy', 'Kitkat ','Crispy & Cruncy','Pcs',75),
(115,'Beverages', 'CocaCola','','Liters',75),
(116,'Cooking', 'Basmati Rice','slender-grained & aromatic rice','Kg',70);

