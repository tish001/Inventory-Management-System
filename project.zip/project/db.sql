--
--database='inventory1'
--
--
-- Table structure for table `admin`
--
 CREATE TABLE IF NOT EXISTS 'admin'
(
'USER_NAME' varchar(30) NOT NULL,
'FIRST_NAME' varchar(30) NOT NULL,
'LAST_NAME' varchar(30) NOT NULL,
'EMAIL' varchar(50) NOT NULL,
'PHONE' varchar(15) NOT NULL,
'PASSWORD1' varchar(30) NOT NULL,
'USER_TYPE' varchar(50) NOT NULL
)ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=latin1;
--data for table 'admin'
INSERT INTO 'product' 
('USERNAME', 'FIRST_NAME','LAST_NAME','EMAIL,PHONE','PASSWORD1','USER_TYPE') 
 VALUES 
 ('admin', 'Tahmina', 'Tisha','tahminatish@gmail.com','01954791639','Admin@123','admin');


