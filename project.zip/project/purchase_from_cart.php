<?php
	include('connection.php');
	if(isset($_COOKIE['USER_NAME'])) $user = $_COOKIE['USER_NAME'];
	if(isset($_SESSION['USER_NAME'])) $user = $_SESSION['USER_NAME'];
	if(!isset($user))
	{
		echo"<script>window.open('login.php?mes=Access Denied..','_self');</script>";
		
	}

?>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

    <style>
        th {
            width: 10%;
            font-size: small;
            font-weight: bolder;
        }

        b {
            color: blueviolet;
            font-weight: lighter;
        }

        .b1 {
            color: blueviolet;
            font-weight: bold;
        }

        .heading {
            font-weight: bolder;
            color: blueviolet;
        }

        p {
            font-weight: bolder;
        }

        .success1 {

            color: green;
            font-weight: bolder;
            text-align: center;
            margin-bottom: 10px;

        }

        .position {
            float: right;
            margin-top: 20px;
            margin-right: 25px;

        }

        .position1 {
            float: right;
            margin-top: 20px;
            margin-right: 20px;

        }

        .position3 {
            float: right;
            margin-top: 20px;
            margin-right: 20px;

        }

        .selectdeg {
            width: 200px;
            height: 27px;

        }

        .modal-dialog {
            width: auto;
            max-width: 900px;
        }

        .error {
            color: #FF0000;
            font-size: medium;
            font-weight: bolder;
            line-height: 30px;
            border-radius: 5px;
            height: 30px;

            text-align: center;
            margin-bottom: 10px;
        }

        span {
            font-weight: bolder;
        }
    </style>
</head>


<body>

    <div class="container-fluid">
    <a href="logout.php"><button class="btn btn-danger btn-md position">
            <span class="glyphicon glyphicon-log-out "></span><b style="font-weight: bolder;color:white;">Logout</b></button></a>
       
        <a href="admin.php"><button class="btn btn-primary btn-md position1">
                <span class="glyphicon glyphicon-home"></span><b style="font-weight: bolder;color:white;">Home</b></button></a>
                <a href="<?php $_SERVER['PHP_SELF']; ?>"><button class="btn btn-success btn-md position">
                <span class="glyphicon glyphicon-refresh "></span><b style="font-weight: bolder;color:white;">Refresh</b></button></a>
        <a href="add_to_cart.php"><button class="btn btn-info btn-md position1">
                <span class="glyphicon glyphicon-shopping-cart"></span><b style="font-weight: bolder;color:white;">Cart</b></button></a>

        <form method="post" action="<?php echo $_SERVER["PHP_SELF"]; ?>">
            </br>




            <?php
            $now = new DateTime();
            echo '<span class=" glyphicon glyphicon-time position3"  style="color:teal;font-weight:bolder;font-size:1.2em;"> PURCHASE DATE: ' . $now->format('d-m-Y') . '</span>'; ?>

            </br></br></br>
            <div>


                <table class="table table-striped">
                    <thead>

                        <tr class="success">
                            <th>PRODUCT ID</th>
                            <th>CATEGORY NAME</th>
                            <th>PRODUCT NAME</th>
                            <th>QUANTITY</th>
                            <th>UNIT</th>
                            <th>UNIT PRICE</th>
                            <th>IMAGE</th>
                            <th>TOTAL PRICE</th>
                            <th>ACTION</th>

                        </tr>
                    <tbody>



                        <?php



                        $sql1 = "select * from cart";
                        //  $sql1 = "SELECT DISTINCT(PRODUCT_ID),DISTINCT(PRODUCT_ID),DISTINCT(PRODUCT_ID),DISTINCT(PRODUCT_ID), FROM cart";
                        $result = $conn->query($sql1);

                        if (!($result->num_rows > 0)) {
                            echo '<div class="error">CART IS EMPTY NOW :( ADD PRODUCT';
                        } else {
                            // output data of each row
                            $i = 0;
                            $no_of_product = 0;
                            $total_price = 0;
                            while ($row = $result->fetch_assoc()) {
                                $image_id1 = $row["PRODUCT_ID"];
                                $total = $row["QUANTITY"] * $row["UNIT_PRICE"];
                                $total_price = $total_price + $total;
                                $no_of_product++;
                        ?>
                                </tr>
                    <tbody>
                        <tr>


                            <td><?php echo '<b style="color:blue;font-weight:bold;">' . $row["PRODUCT_ID"] ?> </td>
                            <td><?php echo '<b>' . $row["CATEGORY_NAME"] ?> </td>
                            <td><?php echo '<b>' . $row["PRODUCT_NAME"] ?> </td>

                            <td><input type="number" readonly style="font-weight: bold;color:teal" required min="1" max="<?php echo $row["QUANTITY"]  ?>" value="<?php echo $row["QUANTITY"] ?>" name="quantity[]"></td>
                            <td><?php echo '<b>' . $row["UNIT"] ?> </td>
                            <td><?php echo '<b>' . $row["UNIT_PRICE"] ?> </td>



                            <td><img src="img/<?php echo $image_id1; ?>.jpg" width="100px" height="100px">

                            </td>
                            <td><?php echo '<b>' . $total ?> </td>


                            <input type="hidden" value="<?php echo $row["PRODUCT_ID"]; ?>" name="pid[]" id="pid">
                            <input type="hidden" value="<?php echo $row["CATEGORY_NAME"]; ?>" name="cname[]">
                            <input type="hidden" value="<?php echo $row["PRODUCT_NAME"]; ?>" name="pname[]">
                            <input type="hidden" value="<?php echo $row["UNIT"]; ?>" name="unit[]">
                            <input type="hidden" value="<?php echo $row["UNIT_PRICE"]; ?>" name="unit_P[]">


                            <td><a href="delcart.php?status_id=<?php echo $row['PRODUCT_ID']; ?>">


                                    <button type="button" class="btn btn-danger" style="width:120px"><span class="glyphicon glyphicon-trash "></span> Delete</button></a>
                                <br><br>

                                <a href="updatecart.php?status_id=<?php echo $row['PRODUCT_ID'] ?>">
                                    <button type="button" class="btn btn-success" name="edit" style="width:120px" ;>

                                        <span style="font-weight:bold"></span>Edit Quantity</button></a>

                            </td>
                        </tr>






                    </tbody>
                    </thead>

                <?php
                                $i++;
                            }



                ?>
                <tfoot>
                    <tr style="background-color:turquoise;height:50px">
                        <td colspan="7">





                            <?php echo '<p>Total Product=' . $no_of_product ?></td>
                        <td colspan="2">
                            <?php echo '<p style="float:right";>Total Price=' . $total_price . '</p>' ?>



                        </td>
                    </tr>
                </tfoot>
                </table>
                <button type="submit" name="submit2" value="PURCHASE" class="btn btn-info btn-lg" style="float:right;margin-right:25px;font-weight:bolder;"><i class="fa fa-shopping-bag it">PURCHASE</i></button>
            <?php









                            if (isset($_POST["submit2"])) {
                                foreach ($_POST['pid'] as $id => $pid) {

                                    $ID = $_POST['pid'][$id];
                                    $C = $_POST['cname'][$id];
                                    $P = $_POST['pname'][$id];
                                    $UNIT = $_POST['unit'][$id];
                                    $UP = $_POST['unit_P'][$id];
                                    //echo $setprice;
                                    //echo'</br>'; 
                                    $Q = $_POST['quantity'][$id];
                                    $setprice = ceil(($UP + (($UP * 3) / 100)));
                                    //echo $setprice;
                                    $t =   $now->format('Y-m-d');
                                    $sql2 = "INSERT INTO purchase(PRODUCT_ID,CATEGORY_NAME,PRODUCT_NAME,QUANTITY,UNIT,UNIT_PRICE,PURCHASE_DATE) VALUES ('$ID','$C', '$P','$Q','$UNIT','$UP','$t')";
                                    if (mysqli_query($conn, $sql2)) {





                                        $s = "SELECT PRODUCT_ID,CATEGORY_NAME,PRODUCT_NAME,UNIT,UNIT_PRICE,QUANTITY,SUM(QUANTITY) as q FROM purchase GROUP BY PRODUCT_ID  ASC";

                                        $result = $conn->query($s);
                                        if (($result->num_rows > 0)) {

                                            while ($row = $result->fetch_assoc()) {
                                                $ID = $row["PRODUCT_ID"];
                                                $PNAME = $row["PRODUCT_NAME"];
                                                $CNAME = $row["CATEGORY_NAME"];
                                                $UNIT = $row["UNIT"];
                                                $UNIT_PRICE = $row["UNIT_PRICE"];
                                                $QUANTITY = $row["QUANTITY"];
                                                $SUMQUANTITY = $row["q"];

                                                $sq = "select * from  stock where PRODUCT_ID='$ID' ";
                                                if (mysqli_query($conn, $sq)) {
                                                    $result1 = $conn->query($sq);
                                                    if (!($result1->num_rows > 0)) {

                                                        $sql = "INSERT INTO stock(PRODUCT_ID,CATEGORY_NAME,PRODUCT_NAME,QUANTITY,UNIT,UNIT_PRICE)VALUES('$ID','$CNAME','$PNAME','$SUMQUANTITY','$UNIT','$UNIT_PRICE')";

                                                        $result2 = $conn->query($sql);
                                                        // echo "Insert";
                                                        //  echo $row["PRODUCT_NAME"];
                                                    } else {
                                                        $sql1 = "UPDATE stock SET QUANTITY='$SUMQUANTITY' where PRODUCT_ID='$ID'";
                                                        $result3 = $conn->query($sql1);
                                                        // echo "Update";
                                                        //echo $row["PRODUCT_NAME"];
                                                    }
                                                }
                                            }
                                        }

















                                        $sql3 = "TRUNCATE TABLE `cart`";
                                        if (mysqli_query($conn, $sql3)) {


                                            echo '<script type="text/javascript">';
                                            echo 'alert(" Purchase Successfull!");';
                                            echo 'window.location.href = "purchase_from_cart.php";';
                                            echo '</script>';
                                        } else {
                                            echo '<div class="error">ERROR IN PURCHASING :(</div>';
                                        }
                                    } else {

                                        echo '<script type="text/javascript">';
                                        echo 'alert(" Purchase unsuccessfull!");';
                                        echo 'window.location.href = "purchase_from_cart.php";';
                                        echo '</script>';
                                    }
                                }
                            }
                        }

                        //$total_p= $total_price;
                        // $no_pro= $no_of_product;



            ?>
        </form>
    </div>

    <body>
    <?php mysqli_close($conn);?>
</html>