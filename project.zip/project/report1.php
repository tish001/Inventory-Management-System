<?php

include('connection.php');

if (!isset($_SESSION["USER_NAME"])) {
    echo "<script>window.open('login.php?mes=Access Denied..','_self');</script>";
}

?>
<html>

<head>
<title> Transaction report </title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>


  
    <style>
        
        .background {
           
           background-image: url('../static/images/doc2.jpg');
           background-size:cover;
     background-position: center;
      
         }
         
         .table {
           width: 600px;
          height: 100px;
      
           }
           .table tr{ 
             height: 60px;
           }
           
   
           .table1 {
             width: 100%;
             height: auto;
             text-align: center;
             border:cadetblue;
          
             }
             .table2 {
               width: 250px;
               height: 20px;
               text-align: center;
               border:cadetblue;
              
          
            
               }
               .position {
            float: right;
            margin-top: 10px;
            margin-right: 25px;

        }

        .position1 {
            float: right;
            margin-top: 10px;
            margin-right: 20px;

        }
           
           .newf
           {
             font-weight: bold;
             color:black;
             
           }
           .pnew {
             color:black;
             font-family: Poppins-bold;
      
            font-size:large;
          font-size: medium ;
   
          src: url('../fonts/poppins/Poppins-Bold.ttf');
           
         
           }
           .error {
            color: #FF0000;
            font-size: medium;
            font-weight: bolder;
            line-height: 30px;
            border-radius: 5px;
            height: 30px;

            text-align: center;
            margin-bottom: 10px;
        }

           .sky
           {
             color:blue;
         font-size: medium;
         font-family: "Times New Roman", Times, serif;
           }
           .sky1
           {
             color:black;
             font-weight: bold;
           }
           .sky3
           {
             color:blue;
             font-weight:bold;
             opacity:0.9;
             
           }
           p{
               float: left;
               margin-left:20px;
              font-size:small;
              font-weight: bold;
               
           }
           
       </style>
</head>

<body class="background" >


<a href="<?php $_SERVER['PHP_SELF']; ?>"><button class="btn btn-success btn-md position">
            <span class="glyphicon glyphicon-refresh "></span><b style="font-weight: bolder;color:white;">Refresh</b></button></a>
    <a href="admin.php"><button class="btn btn-primary btn-md position1">
            <span class="glyphicon glyphicon-home"></span><b style="font-weight: bolder;color:white;">Home</b></button></a>
            <br />&nbsp;

  <h1 style=" text-align: center; color: blue; font-weight:bold;size:100px; opacity:0.4;">TRANSACTION REPORT</h1><hr>
  
  

    <div class="container-fluid">
        </br>
        <form role="form" method="post" action="<?php echo $_SERVER["PHP_SELF"]; ?>">


        <input type="submit" name="submit" value="Search">
<input type="date" name="date1" required>
<LABEL>TO
<input type="date" name="date2" required></LABEL>
</form>  
<?php 
if ($_SERVER["REQUEST_METHOD"] == "POST") {
?>
<form role="form" method="post" action="<?php echo $_SERVER["PHP_SELF"]; ?>">

  <table class="table1" border="1px"  style="margin-top:0px;">
    <thead>
        <tr>
        
        <th style="text-align: center;color:blue; vertical-align: middle;" bgcolor="lightblue" class="pnew" colspan="6">DAILY PURCHASE REPORT</th>
    </tr>
    <tbody>
        <tr class="sky">  
            <td>Product ID</td>
            <td>Category Name</td>
            <td>Product Name</td>
            <td>Quantity</td>
            <td>Unit Price</td>
            <td>Total Price</td>
        </tr>
        <tr class="sky">
            <?php
            
                // $date=$_POST["date1"];
                $date1=$_POST["date1"];
                $date2=$_POST["date2"];
        $sql="select * from purchase  where PURCHASE_DATE >='$date1' and PURCHASE_DATE <='$date2' GROUP BY PRODUCT_ID";
        $res = mysqli_query($conn, $sql);
        if ($res->num_rows > 0) {
            $cost=0;
            $no_of_product = 0;
            while($row=$res->fetch_assoc()){
                $cost=$cost+($row["QUANTITY"]*$row["UNIT_PRICE"]);
                $no_of_product++;
                

              ?>
<tr><td ><?php echo $row["PRODUCT_ID"]?></td>
<td><?php echo $row["CATEGORY_NAME"]?></td>
<td><?php echo $row["PRODUCT_NAME"]?></td>
<td><?php echo $row["QUANTITY"].$row["UNIT"]?></td>
<td><?php echo $row["UNIT_PRICE"]?></td>
<td><?php echo $row["QUANTITY"]*$row["UNIT_PRICE"]?></td>


<?php 


} ?>        
           
       

        </tr>
      
    </tbody>
    </thead>
    <tfoot >
                    <tr  style="background-color:whitesmoke;">
                        <td colspan="6"><?php echo "<p>Total Parchased Product:  $no_of_product </p>" ?>
      
                         
                            <?php echo "<p style='float:right;margin-right:20px;'>Total Cost Price:  $cost </p>" ?>
        </tr>

        <?php 



}
else
{
echo '<div class="error">NO  PURCHASE HAS BEEN DONE IN THIS DATE</div>';
}




?>


                        </td>
                    </tr>
                </tfoot>
</table>


</br>


  <table class="table1" border="1px"  style="margin-top:0px;">
    <thead>
        <tr>
        
        <th style="text-align: center;color:blue; vertical-align: middle;" bgcolor="lightblue" class="pnew" colspan="8">DAILY SELL REPORT</th>
    </tr>
    <tbody>
        <tr class="sky">  
            <td>Product ID</td>
            <td>Category Name</td>
            <td>Product Name</td>
            <td>Quantity</td>
            <td>Unit Sell Price</td>
            <td>Total Price</td>
            <td>PROFIT</td>
            <td>LOSS</td>
        </tr>
        <tr class="sky">
            <?php
           
                //$date=$_POST["date1"];
              
              //echo $_POST["date1"];
        $sql1="select PRODUCT_ID,CATEGORY_NAME,PRODUCT_NAME,QUANTITY,UNIT_SELL_PRICE,TOTAL_SELL_PRICE,SUM(PROFIT) as PROFIT,SUM(LOSS) AS LOSS from sell  where SELL_DATE ='{$_POST["date1"]}' GROUP BY PRODUCT_ID";
        $res1 = mysqli_query($conn, $sql1);
        if ($res1->num_rows > 0) {
            $sell=0;
            $no_of_product = 0;
            $profit=0;
            $loss=0;
            while($row=$res1->fetch_assoc()){
                $sell=$sell+($row["TOTAL_SELL_PRICE"]);
                $no_of_product++;
               $profit=$profit+($row["PROFIT"]);
               $loss=$loss+($row["LOSS"]);
              ?>
<tr><td ><?php echo $row["PRODUCT_ID"]?></td>
<td><?php echo $row["CATEGORY_NAME"]?></td>
<td><?php echo $row["PRODUCT_NAME"]?></td>
<td><?php echo $row["QUANTITY"]?></td>
<td><?php echo $row["UNIT_SELL_PRICE"]?></td>
<td><?php echo $row["TOTAL_SELL_PRICE"]?></td>
<td><?php echo $row["PROFIT"]?></td>
<td><?php echo $row["LOSS"]?></td>


<?php 



} ?>        

       

        </tr>
      
    </tbody>
    </thead>
    <tfoot >
                    <tr  style="background-color:whitesmoke;">
                        <td colspan="8"><?php echo "<p>Total Parchased Product:  $no_of_product </p>" ?>
                        <?php echo "<p style='float:right;color:red;'>Total Loss:  $loss </p>" ?>
                        <?php echo "<p style='float:right;'>Total Profit:  $profit </p>" ?>
                      
                            <?php echo "<p style='float:right;'>Total Sell Price:  $sell </p>" ?>
                       
        </tr>
        

        <?php 



}
else
{
echo '<div class="error">NO SELL HAS BEEN DONE IN THIS DATE</div>';
}




//echo $cost-$sell;
 
 
 
 
 
 }
 ?>
    </form>

        </div>
        </body>
        </html>