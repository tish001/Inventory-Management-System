CREATE TABLE IF NOT EXISTS `category` (
  `CATEGORY_ID` int(10) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `CATEGORY_NAME` varchar(250) NOT NULL UNIQUE
  
) ENGINE=InnoDB  DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`CATEGORY_NAME`) VALUES
('Fruit'),
('Vegetable'),
('Beverages'),
('Meat'),
('Fish'),
('Snacks'),
('Dairy'),
('Bread&Bakery'),
('Cooking');
