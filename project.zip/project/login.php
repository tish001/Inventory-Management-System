
<?php

include ('connection.php');


?>
<html class="backimg">	<link rel="stylesheet" type="text/css" href="style1.css">	
	<head>
    <title>Inventory Management System</title>
	
	
	</head>
	<body class="back">




    <?php
         if (isset($_POST["login"])) {

            $sql = "select * from admin where USER_NAME='{$_POST["username"]}' and PASSWORD1='{$_POST["pass1"]}'";
            $res = mysqli_query($conn, $sql);
            if ($res->num_rows > 0) {
                $ro = $res->fetch_assoc();
               
              
                if (!empty($_POST["remember"])) {
                $cookie_name ="USER_NAME";
               
                $_SESSION["USER_NAME"] = $ro["USER_NAME"];
                $cookie_value =  $_SESSION["USER_NAME"];
              
                setcookie($cookie_name,$cookie_value, time() + 15*60);
            echo "<script>window.open('admin.php','_self');</script>";
           
                
            }
            else
            {
                $_SESSION["USER_NAME"] = $ro["USER_NAME"];
                $_SESSION["PASSWORD1"] = $ro["PASSWORD1"];
                $_SESSION["FIRST_NAME"] = $ro["FIRST_NAME"];
                $_SESSION["LAST_NAME"] = $ro["LAST_NAME"];
           echo "<script>window.open('admin.php','_self');</script>";
        
            }
        }
        
        else{
echo '<div class="error">no account is found</div>';
        }
       }
            

       mysqli_close($conn);
        ?>



       <!-- <img src="admin.jpg" width="800" height='300'>-->
    </br>
        <h1 class="heading " class="lab">LOG IN</h1>
		
		
			<div class="log">
				<form method="post" action="<?php echo $_SERVER["PHP_SELF"]; ?>">
                <label class="lab">User Name</label><br><br>
                 
                    <input type="text" name="username" required class="input" autofocus autocomplete placeholder="Enter username"><br><br>

				<label class="lab">Password</label><br></br>
                      
                
                        <input type="password" name="pass1" required class="input" placeholder="Enter password" ><br><br>
                        <input type="checkbox" name="remember" ><label style="font-size: medium;">Remember me</label><br><br>
                        
                        <button type="submit" class="btn " name="login">LOG IN</button>
					
				</form>
			</div>
		
		</body>
		
		</html>
		