<html>

<head>

	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

<style>
.c1 {

/*background-image: url('img/back1.jpg');
background-repeat: repeat-y;*/
float: left;
margin-left: 50px;
color:white;
font-weight: bolder;

}
</style>

</head>

<div class="sidebar"><br>
	<h2  class="text c1">Dashboard</h2><br>
	<br>
	<ul>
		<?php

			echo '
					<li class="li"><a href="management.php">About Management System</a></li>
					<li class="li"><a href="editprofile1.php""target="_blank">Edit Profile</a>
					<li class="li"><a href="product.php"> Product Information Management</a></li>
					<li class="li" style="color:blue;font-size:bold";>Stock Management: </br>
				<ol>	<a href="add_to_cart.php">Add Product to Cart </a></ol>
			<ol>	<a href="purchase_from_cart.php">Purchase Product From Cart</a></ol>
			<ol>	<a href="sellproduct.php">Sell Product</a></ol>

					</li>
				
					<li class="li" style="color:blue;font-size:bold";>Stock Status & Transaction Report:</a>

					<ol>	<a href="stock_status.php">Current Stock Status </a></ol>
					<ol>	<a href="dailyreport.php">Daily transaction Report</a></ol>
					<ol>	<a href="month_report.php">Date Range Wize Report</a></ol></li>
				';
		


		?>


	</ul>

</div>

</html>