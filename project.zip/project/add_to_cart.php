<?php
	include('connection.php');
	if(isset($_COOKIE['USER_NAME'])) $user = $_COOKIE['USER_NAME'];
	if(isset($_SESSION['USER_NAME'])) $user = $_SESSION['USER_NAME'];
	if(!isset($user))
	{
		echo"<script>window.open('login.php?mes=Access Denied..','_self');</script>";
		
	}

?>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

    <style>
        th {
            width: 8%;
            font-size: small;
            font-weight: bolder;
        }
     

        b {
            color: blueviolet;
            font-weight: lighter;
        }

        .b1 {
            color: blueviolet;
            font-weight: bold;
        }

        .heading {
            font-weight: bolder;
            color: blueviolet;
        }

        p {
            font-weight: bolder;
        }

        .success1 {

            color: green;
            font-weight: bolder;
            text-align: center;
            margin-bottom: 10px;

        }

        .position {
            float: right;
            margin-top: 10px;
            margin-right: 25px;

        }

        .position1 {
            float: right;
            margin-top: 10px;
            margin-right: 20px;

        }

        .selectdeg {
            width: 200px;
            height: 27px;

        }

        .modal-dialog {
            width: auto;
            max-width: 900px;
        }

        .error{
            color: #FF0000;
            font-size: medium;
            font-weight: bolder;
            line-height: 30px;
            border-radius: 5px;
            height: 30px;

            text-align: center;
            margin-bottom: 10px;
        }

        span {
            font-weight: bolder;
        }
        input
        {
            width: 90%;
            float: center;
            
        }
        input.larger {
        width: 40px;
        height: 30px;
 
      }
      .bord
      {
        border-width:0px;
border:none;
background-color: whitesmoke;
font-weight: bold;
      }
    </style>
</head>


<body>
<a href="logout.php"><button class="btn btn-danger btn-md position">
            <span class="glyphicon glyphicon-log-out "></span><b style="font-weight: bolder;color:white;">Logout</b></button></a>

    
    <a href="admin.php"><button class="btn btn-primary btn-md position1">
            <span  class="glyphicon glyphicon-home" ></span><b style="font-weight: bolder;color:white;">Home</b></button></a>
            <a href="<?php $_SERVER['PHP_SELF']; ?>"><button class="btn btn-success btn-md position">
            <span class="glyphicon glyphicon-refresh "></span><b style="font-weight: bolder;color:white;">Refresh</b></button></a>
            <a href="purchase_from_cart.php"><button class="btn btn-info btn-md position1">
            <span  class="glyphicon glyphicon-shopping-cart" ></span><b style="font-weight: bolder;color:white;">Purchase</b></button></a>
  
  
            <br />&nbsp;
  
            <div class="container-fluid">
    </br>
        <form role="form" method="post" action="<?php echo $_SERVER["PHP_SELF"]; ?>">

         
           
                <table class="table table-striped">
                    <tr>
                   <td>
                            <p>CATEGORY NAME<p>




                                    <select name="cname" id="cname" required class="selectdeg">

                                        <?php

                                        $sl = "SELECT DISTINCT(CATEGORY_NAME) FROM product";
                                        $r = $conn->query($sl);
                                        $ar = array();
                                        if ($r->num_rows > 0) {

                                            echo "<option value=''>Select Category</option>";
                                            while ($ro = $r->fetch_assoc()) {
                                                echo "<option value='{$ro["CATEGORY_NAME"]}'>{$ro["CATEGORY_NAME"]} </option>";
                                            }
                                        }

                                        ?>

                                    </select>
                                    <span class="error">*</span>
                        </td>

                    </tr>
                    <tr>
                        <td>
                            <button type="submit" class="btn btn-success" value="submit" name="submit">submit</button>
                            
                    </tr>
                    </td>
                </table>
                                  
                                    </form>
                                    </div>
                                    <form role="form" method="post"  action="<?php echo $_SERVER["PHP_SELF"]; ?>">
               
            
                                    <div class="container-fluid">
                    <table class="table table-striped">
                        <thead>
                            <tr class="success">
                                <th>PRODUCT ID</th>
                                <th>CATEGORY NAME</th>
                                <th>PRODUCT NAME</th>
                               
                                <th>QUANTITY</th>
                                <th>UNIT</th>
                                <th>UNIT PRICE</th>
                                <th>IMAGE</th>
                                <th>ADD TO CART</th>

                            </tr>
                        <tbody>

                            <?php



                            if (isset($_POST["submit"])) {
              
                              $c = $_POST["cname"];

                                $sql4 = "select * from product where CATEGORY_NAME='$c'";
                                $result = mysqli_query($conn, $sql4);
                            

                            if ($result->num_rows > 0) {
                                // output data of each row
                      
                      $i=0;
                                while ($row = $result->fetch_assoc()) {
                                  $image_id = $row["PRODUCT_ID"];
                                  // echo $image_id;
                      
                              ?>
                                  </tr>
                            <tbody>
                              <tr>
                                  <td><input type="text" readonly value="<?php echo $row["PRODUCT_ID"];?>"name="pid[]"class="bord"></td>
                                  <td><input type="text"  value="<?php echo $row["CATEGORY_NAME"];?>"name="cname[]"class="bord"></td>
                                  <td><input type="text" readonly value="<?php echo $row["PRODUCT_NAME"];?>"name="pname[]" class="bord"></td>
                      
                                <td> <input type="number" style="font-weight: bold;color:teal"  min="1" value="1" name="quantity[]" required>
                      <span class="error">*</span></td>
                      <td><input type="text" readonly value="<?php echo $row["UNIT"];?>"name="u[]"class="bord"></td>
                      <td><input type="text" readonly value="<?php echo $row["UNIT_PRICE"];?>"name="u_p[]"class="bord"></td>
                                
                                <td><img src="img/<?php echo $image_id; ?>.jpg" width="100px" height="100px">
                                </td>
                      <td>
                      
     <input type="checkbox" class="larger" name="status[<?php echo $i; ?>]" value="status"><span class="glyphicon glyphicon-shopping-cart" style="color:red;font-size:2.1em;"></span>
                                  
                                </td>
                            
                              </tr>
                             
                      
                          <?php
                          $i++;
                                }
                      
                            }
                            else
                            {
                                echo "No record Found";
                            }
                              ?>  <tr><td colspan="8">
                                  </br>
                                <button type="submit"  name="submit1" class="btn btn-danger btn-lg"style="float:right;margin-right:50px;"><span class="glyphicon glyphicon-shopping-cart"></span>ADD TO CART</button>
                                  </tr></td>
                                <?php 
                               
                              }
                            
                           
                          ?>



</tbody>
                            </thead>
                          </table>
                          </div>
                        

<?php
if(isset($_POST['submit1']))
{
    if(!empty($_POST['status'])){
  foreach($_POST['status'] as $id => $status) {
	?>
	
    
    <?php
        $ID= $_POST['pid'][$id];
        $C= $_POST['cname'][$id];
		$P=$_POST['pname'][$id];
		$Q=$_POST['quantity'][$id];
		$U=$_POST['u'][$id];
		$UP = $_POST['u_p'][$id];
        
        $sql4 = "select * from cart where PRODUCT_ID=$ID";
    $res = mysqli_query($conn, $sql4);
    if ($res->num_rows > 0) {
      $ro = $res->fetch_assoc();
      $pid1 = $ro["PRODUCT_ID"];
      if (($pid1) == ($ID)) {
        echo "<div class='error'>This Product is already in cart!</div>";
      }
    } 
else{


		
     $sql1= "INSERT INTO cart(PRODUCT_ID,CATEGORY_NAME,PRODUCT_NAME,QUANTITY,UNIT,UNIT_PRICE) VALUES ('$ID','$C', '$P','$Q','$U','$UP')";
    if(mysqli_query($conn, $sql1)){
		echo  '<div class="success1">' .$P. ' Has been added to Cart!</div>';
    } else{
		
        echo "\n error" ;
    }
}
  } 
    }
  else{
echo "<div class='error'>PLEASE SELECT A PRODUCT!</div>";
  }
}
    ?>
               
                            </form>
        
                           

</body>
<?php mysqli_close($conn);?>
</html>