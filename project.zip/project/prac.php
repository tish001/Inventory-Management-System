
<?php
/*$date   = new Datetime(); //this returns the current date time
$result = $date->format('d/m/Y');
$date1=date_create("1997/01/01");
$date2=date_create("2020/01/01");
$d1=$date1->format('d/m/Y');
$d2=$date2->format('d/m/Y');


//

echo $d1;
//echo $d2;



$krr    = explode('/', $d1);
//echo $krr[2]."<br>";
$n=$krr[2];
$d=$krr[1];

if($n>=1997 && $n<=2000 && $d>12)
{
    echo "error";
}
else{
//$result = implode("/", $krr);
echo "no";
}
/*
function isDate($string) {
    $matches = array();
    $pattern = '/^([0-9]{1,2})\\/([0-9]{1,2})\\/([0-9]{4})$/';
    if (!preg_match($pattern, $string, $matches)) return false;
    if (!checkdate($matches[2], $matches[1], $matches[3])) return false;
    return true;
}

$a="CSE234,CSE234,CSE456,";
echo $a;
$r=explode(',',$a);
$t=count($r)-1;
echo $t;
$sum=0;
$sum=$sum+($t*4);
echo $sum;
if($sum>=9 && $sum<=15)
{
    echo "success";
}
else{
    echo "error";
}*/



include('connection.php');

if (!isset($_SESSION["USER_NAME"])) {
    echo "<script>window.open('login.php?mes=Access Denied..','_self');</script>";
}

?>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

    <style>
        th {
            width: 8%;
            font-size: small;
            font-weight: bolder;
        }


        b {
            color: blueviolet;
            font-weight: lighter;
        }

        .b1 {
            color: blueviolet;
            font-weight: bold;
        }

        .heading {
            font-weight: bolder;
            color: blueviolet;
        }

        p {
            font-weight: bolder;
        }

        .success1 {

            color: green;
            font-weight: bolder;
            text-align: center;
            margin-bottom: 10px;

        }

        .position {
            float: right;
            margin-top: 10px;
            margin-right: 25px;

        }

        .position1 {
            float: right;
            margin-top: 10px;
            margin-right: 20px;

        }
  .position3 {
            float: right;
            margin-top: 5px;
            margin-right: 20px;

        }

        .selectdeg {
            width: 200px;
            height: 27px;

        }

        .modal-dialog {
            width: auto;
            max-width: 900px;
        }

        .error {
            color: #FF0000;
            font-size: medium;
            font-weight: bolder;
            line-height: 30px;
            border-radius: 5px;
            height: 30px;

            text-align: center;
            margin-bottom: 10px;
        }

        span {
            font-weight: bolder;
        }

        input {
            width: 90%;
            float: center;

        }

        input.larger {
            width: 40px;
            height: 30px;

        }

        .bord {
            border-width: 0px;
            border: none;
            background-color: whitesmoke;
            font-weight: bold;
        }
    </style>
</head>


<body>

    <a href="<?php $_SERVER['PHP_SELF']; ?>"><button class="btn btn-success btn-md position">
            <span class="glyphicon glyphicon-refresh "></span><b style="font-weight: bolder;color:white;">Refresh</b></button></a>
    <a href="admin.php"><button class="btn btn-primary btn-md position1">
            <span class="glyphicon glyphicon-home"></span><b style="font-weight: bolder;color:white;">Home</b></button></a>

    <br />&nbsp;

    <div class="container-fluid">
        </br>
        <form role="form" method="post" action="<?php echo $_SERVER["PHP_SELF"]; ?>">
     <?php   $now = new DateTime();
            echo '<span class=" glyphicon glyphicon-time position3"  style="color:teal;font-weight:bolder;font-size:1.2em;"> PURCHASE DATE: ' . $now->format('d-m-Y H:i:s') . '</span>'; ?>
</br>&nbsp;

            <table class="table table-striped">
                <tr>
                    <td>
                        <p>CATEGORY NAME<p>




                        

                                    <?php

                                    $sl = "SELECT DISTINCT(CATEGORY_NAME),QUANTITY FROM stock";
                                    $r = $conn->query($sl);

                                    $ar = array();
                                    if ($r->num_rows > 0) {
                                        while ($ro = $r->fetch_assoc()) {
                                        if($ro["QUANTITY"]!=0){
                                            echo $ro["CATEGORY_NAME"];
                                        //     echo $ro["QUANTITY"];

                                        }
                                    }
        
                                        // $i=0;
                                        // while ($ro = $r->fetch_assoc()) {
                                         
                                        //     $ar[$i] = $ro["CATEGORY_NAME"];
                                        //     echo $ro["CATEGORY_NAME"];
                                        //     echo $ro["QUANTITY"];
                                        //     $i++;
                                        // }
                                    }










?>
