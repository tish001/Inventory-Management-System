<?php

include('connection.php');

if(!isset($_SESSION["USER_NAME"]))
{
    echo"<script>window.open('login.php?mes=Access Denied..','_self');</script>";
    
}
$var = $_GET['status_id'];


?>
<html>
    <head>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    

    </head>



    <body>
    <form role="form" method="post">
    <table class="table table-striped">
      <?php $sql="select * from cart where PRODUCT_ID='$var'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  

  while($row = $result->fetch_assoc()) {?>
    <tr><td><p>PRODUCT ID</p> </td></tr>
    <tr><td> <?php echo $row['PRODUCT_ID'];?>   </tr></td>  
 
    <tr><td><p>PRODUCT NAME</p> </td></tr>
    <tr><td>   <?php echo $row['PRODUCT_NAME'];?>   </tr></td>  
     <?php $s1="select * from cart where PRODUCT_ID='$var'";
     $result=$conn->query($s1);
     if ($result->num_rows > 0) {
      while($row = $result->fetch_assoc()) {
     $quan=$row["QUANTITY"];
     
      }
    }


     ?>
      <tr><td><p>QUANTITY</p> </td></tr>
   <tr><td>  <input type="number" value="<?php echo $quan;?>" min="1"  name="quantity1" >  </td></tr>

      
  <tr><td>    <button type="submit" class="btn btn-default"  name="edit" value="edit" >Edit</button></tr></td>

</table>
  <?php } }?>

  <?php

if (isset($_POST["edit"])) {
 
   
    $q1= $_POST["quantity1"];

  

         $sql2 ="UPDATE cart SET QUANTITY='$q1' where PRODUCT_ID='$var'";


         if (mysqli_query($conn,$sql2)) { 
           //echo "<script>window.open('cart.php','_self');</script>";
     
       
           echo '<script type="text/javascript">'; 
           echo 'alert("quantity updated successfully");'; 
        echo 'window.location.href = "purchase_from_cart.php";';
           echo '</script>';
         }
          else{
           echo '<script type="text/javascript">'; 
           echo 'alert("update failed");'; 
           echo 'window.location.href = "updatep.php";';
           echo '</script>';
          }
       }

     

?>
  </form>
  </body>
  </html>






    
 

