

<?php
include('connection.php');
if (!isset($_SESSION["USER_NAME"])) {
	echo "<script>window.open('login.php?mes=Access Denied...','_self');</script>";
}
?>


<html>

<head>
	<title>Inventory Mangement System</title>
    <link rel="stylesheet" type="text/css" href="style1.css">
    <style>

.b1
{
	background-image: url('img/profile1.jpg');

	background-size: cover;

	
  
}
.log1{
	height:65%;
	width:50%;
	margin:0 auto;
	margin-top:100px;
	padding:30px;
	margin-bottom:50px;
	background-color: whitesmoke;

	 -webkit-box-shadow: 0 8px 17px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
  -moz-box-shadow: 0 9px 17px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
  box-shadow: 0 8px 17px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
}



    </style>

</head>

<body class="b1">
	<?php include "navbar.php"; ?><br>


		

			
	<?php
	if (isset($_POST["submit"])) {

		$sql = "select * from admin";
		$result = mysqli_query($conn, $sql);
		if ($result->num_rows > 0) {
			while ($row = $result->fetch_assoc()) {
		
			if($_POST["opass"]!=$row["PASSWORD1"]){

				
					echo '<script type="text/javascript">';
						echo 'alert("Current Password is wrong!");';
						echo 'window.location.href = "editprofile1.php";';
						echo '</script>';
				}
			else{
			if ($_POST["npass"] == $_POST["cpass"]) {
				$s = "update admin SET PASSWORD1='{$_POST["npass"]}' where USER_NAME='{$_SESSION["USER_NAME"]}'";
				mysqli_query($conn, $s);
				echo '<script type="text/javascript">';
				echo 'alert(" Password has been changed Successfully!");';
				echo 'window.location.href = "admin.php";';
				echo '</script>';
			} else {
				echo '<script type="text/javascript">';
				echo 'alert(" Password Mismatched!");';
				echo 'window.location.href = "editprofile1.php";';
				echo '</script>';
			}
		} 
	}
}
	}


    ?>
   <div class="log1">
			<form method="post"  action="<?php echo $_SERVER["PHP_SELF"]; ?>">

	
		
			
<h3>CHANGE PASSWORD</h3><br>

			<label>Current Password</label><br>
					<input type="password" class="input3" name="opass" required placeholder="Enter your current password"><br><br>	

					<label> New Password</label><br>
					<input type="password" class="input3" name="npass" required  pattern=".{3,}" placeholder="password must be 3 or more characters"><br><br>
					<label> Confirm password</label><br>
					<input type="password" class="input3" name="cpass" required placeholder="Enter your new password to confirm"><br><br>
					<button type="submit" class="btn " name="submit">Change Password</button>
			</div>
				
	</form>

			



</body>

</html>