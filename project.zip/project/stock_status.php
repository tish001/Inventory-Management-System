<?php
	include('connection.php');
	if(isset($_COOKIE['USER_NAME'])) $user = $_COOKIE['USER_NAME'];
	if(isset($_SESSION['USER_NAME'])) $user = $_SESSION['USER_NAME'];
	if(!isset($user))
	{
		echo"<script>window.open('login.php?mes=Access Denied..','_self');</script>";
		
	}

?>
<html>

<head>
<title> STOCK STATUS REPORT </title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>


  
    <style>
        
        .background {
           
           background-image: url('../static/images/doc2.jpg');
           background-size:cover;
     background-position: center;
      
         }
         
         .table {
           width: 600px;
          height: 100px;
      
           }
           .table tr{ 
             height: 60px;
           }
           
   
           .table1 {
             width: 100%;
             height: auto;
             text-align: center;
             border:cadetblue;
          
             }
             .table2 {
               width: 250px;
               height: 20px;
               text-align: center;
               border:cadetblue;
              
          
            
               }
               .position {
            float: right;
            margin-top: 10px;
            margin-right: 25px;

        }

        .position1 {
            float: right;
            margin-top: 10px;
            margin-right: 20px;

        }
           
           .newf
           {
             font-weight: bold;
             color:black;
             
           }
           .pnew {
             color:black;
             font-family: Poppins-bold;
      
            font-size:large;
          font-size: medium ;
   
          src: url('../fonts/poppins/Poppins-Bold.ttf');
           
         
           }
           .error {
            color: #FF0000;
            font-size: medium;
            font-weight: bolder;
            line-height: 30px;
            border-radius: 5px;
            height: 30px;

            text-align: center;
            margin-bottom: 10px;
        }

           .sky
           {
             color:blue;
         font-size: medium;
         font-family: "Times New Roman", Times, serif;
           }
           .sky1
           {
             color:black;
             font-weight: bold;
           }
           .sky3
           {
             color:blue;
             font-weight:bold;
             opacity:0.9;
             
           }
           p{
               float: left;
               margin-left:20px;
              font-size:small;
              font-weight: bold;
               
           }
           
       </style>
</head>

<body class="background" >

<a href="logout.php"><button class="btn btn-danger btn-md position">
            <span class="glyphicon glyphicon-log-out "></span><b style="font-weight: bolder;color:white;">Logout</b></button></a>

    <a href="admin.php"><button class="btn btn-primary btn-md position1">
            <span class="glyphicon glyphicon-home"></span><b style="font-weight: bolder;color:white;">Home</b></button></a>
            <a href="<?php $_SERVER['PHP_SELF']; ?>"><button class="btn btn-success btn-md position">
            <span class="glyphicon glyphicon-refresh "></span><b style="font-weight: bolder;color:white;">Refresh</b></button></a>
            <br />&nbsp;

  <h1 style=" text-align: center; color: blue; font-weight:bold;size:100px; opacity:0.4;">STOCK STATUS</h1><hr>
  
  

    <div class="container-fluid">
        </br>
        <form role="form" method="post" action="<?php echo $_SERVER["PHP_SELF"]; ?>">



  <table class="table1" border="1px"  style="margin-top:0px;">
    <thead>
        <tr>
        
        <th style="text-align: center;color:blue; vertical-align: middle;" bgcolor="lightblue" class="pnew" colspan="7">STOCK STARUS REPORT</th>
    </tr>
    <tbody>
        <tr class="sky">  
            <td>Product ID</td>
            <td>Category Name</td>
            <td>Product Name</td>
            <td>Quantity</td>
            <td>Unit Price</td>
            <td>Total Price</td>
            <td>Status</td>
        </tr>
        <tr class="sky">
            <?php
            
                // $date=$_POST["date1"];
        $sql="select * from stock";
        $res = mysqli_query($conn, $sql);
        if ($res->num_rows > 0) {
        
            $no_of_product = 0;
            $asset=0;
            while($row=$res->fetch_assoc()){
      if($row["QUANTITY"]!=0){
                $no_of_product++;
                $status="available!";
      }
      else
      {
          $status="empty";
      }
                $asset=$asset+($row["QUANTITY"]*$row["UNIT_PRICE"]);
                

              ?>
<tr><td ><?php echo $row["PRODUCT_ID"]?></td>
<td><?php echo $row["CATEGORY_NAME"]?></td>
<td><?php echo $row["PRODUCT_NAME"]?></td>
<td><?php echo $row["QUANTITY"].$row["UNIT"]?></td>

<td><?php echo $row["UNIT_PRICE"]?></td>
<td><?php echo $row["UNIT_PRICE"]*$row["QUANTITY"]?></td>
<td></b>

<?php 

if($status=="empty")
{
    
    echo '<b style=color:red;>'.$status.'</b>';
}
else
{
   echo '<b style="color:green;">'. $status.'</b>';
}
    ?>
    </td>
<?php    



} ?>        
           
       

        </tr>
      
    </tbody>
    </thead>
    <tfoot >
                    <tr  style="background-color:whitesmoke;">
                        <td colspan="7"><?php echo "<p>Total Product In Stock:  $no_of_product </p>" ?>
      
                         
                          
        </tr>
        <tr  style="background-color:whitesmoke;">
                        <td colspan="7"><?php echo "<p>Total Asset: $asset  </p>" ?>
      
                         
                          
        </tr>

        <?php 



}
else
{
echo '<div class="error">NO  PRODUCT IS IN STOCK </div>';
}





?>


                        </td>
                    </tr>
                </tfoot>
</table>



    </form>

        </div>
        </body>
        <?php mysqli_close($conn);?>
        </html>