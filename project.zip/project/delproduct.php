<?php

include('connection.php');

if(!isset($_SESSION["USER_NAME"]))
{
    echo"<script>window.open('login.php?mes=Access Denied..','_self');</script>";
    
}

$var = $_GET['status_id'];
$sql= "DELETE FROM `product` WHERE PRODUCT_ID = '$var'";

if (mysqli_query($conn, $sql)) {
   // echo "Record deleted successfully";
    echo "<script>window.open('product.php','_self');</script>";
} else {
    echo "Error deleting record: " . mysqli_error($conn);
}

mysqli_close($conn);

?>