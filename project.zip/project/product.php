<?php
	include('connection.php');
	if(isset($_COOKIE['USER_NAME'])) $user = $_COOKIE['USER_NAME'];
	if(isset($_SESSION['USER_NAME'])) $user = $_SESSION['USER_NAME'];
	if(!isset($user))
	{
		echo"<script>window.open('login.php?mes=Access Denied..','_self');</script>";
		
	}

?>
<html>

<head>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

  <style>
   
    th {
      width: 10%;
      font-size: small;
      font-weight: bolder;
    }

    b {
      color: blueviolet;
      font-weight: lighter;
    }

    .b1 {
      color: blueviolet;
      font-weight: bold;
    }

    .heading {
      font-weight: bolder;
      color: blueviolet;
    }

    p {
      font-weight: bolder;
    }

    .success1 {

      color: green;
      font-weight: bolder;
      text-align: center;
      margin-bottom: 10px;

    }

    .position {
      float: right;
      margin-top: 10px;
      margin-right: 25px;

    }

    .position1 {
      float: right;
      margin-top: 10px;
      margin-right: 20px;

    }

    .selectdeg {
      width: 200px;
      height: 27px;

    }

    .modal-dialog {
      width: auto;
      max-width: 900px;
    }

    .error {
      color: #FF0000;
      font-size: medium;
      font-weight: bolder;
      line-height: 30px;
      border-radius: 5px;
      height: 30px;

      text-align: center;
      margin-bottom: 10px;
    }

    span {
      font-weight: bolder;
    }
  </style>
</head>


<body>
<a href="logout.php"><button class="btn btn-danger btn-md position">
            <span class="glyphicon glyphicon-log-out "></span><b style="font-weight: bolder;color:white;">Logout</b></button></a>
  <a href="<?php $_SERVER['PHP_SELF']; ?>"><button class="btn btn-success btn-md position">
      <span class="glyphicon glyphicon-refresh "></span><b style="font-weight: bolder;color:white;">Refresh</b></button></a>
      <a href="admin.php"><button class="btn btn-primary btn-md position1">
      <span class="glyphicon glyphicon-home"></span><b style="font-weight: bolder;color:white;">Home</b></button></a>
  <?php

  if (isset($_POST["submit"])) {
    $pid = $_POST["pid"];
    $c = $_POST["cname"];
    $pname = $_POST["pname"];
    $des = $_POST["descript"];
 

    $u = $_POST["unit"];
    $u_p = $_POST["unit_price"];

    $sql4 = "select * from product where PRODUCT_ID='$pid'";
    $res = mysqli_query($conn, $sql4);
    if ($res->num_rows > 0) {
      $ro = $res->fetch_assoc();
      $pid1 = $ro["PRODUCT_ID"];
      if (($pid1) == ($pid)) {
        echo "<div class='error'>This Product ID already exists!</div>";
      }
    } 
    
    else {

      $sql = "insert into product
            (PRODUCT_ID,CATEGORY_NAME,PRODUCT_NAME,DESCRIPTION,UNIT,UNIT_PRICE) VALUES
            ('$pid','$c','$pname','$des','$u','$u_p')";

      if (mysqli_query($conn, $sql)) {


        echo "<div class='success1'>Insert Success.</div>";
      } else {
        echo "<div class='error'>Insert Error.</div>";
      }
    }
  }

  ?>




  <div class="container-fluid">
    <!-- Trigger the modal with a button -->
    </br>

    <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal" style="margin-top: 20px;margin-left:15px;">Add Product</button>

    <!-- Modal -->
    <div class="modal fade" id="myModal" role="dialog">
      <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title"><b class="heading">Add Product</b></h4>
          </div>
          <div class="modal-body">
            <form role="form" method="post">
              <div class="container-fluid">
                <table class="table table-striped">


                  <tr>
                    <td>
                      <p>PRODUCT ID<p>
                    </td>
                  </tr>
                  <tr>
                    <td> <input type="text" name="pid" required pattern="^(1)([0-9]{2,4})$" placeholder="start with 1,atleast 3 digit">
                      <span class="error">*</span> </td>
                  </tr>
                  <tr>
                    <td>
                      <p>CATEGORY NAME<p>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <select name="cname" required class="selectdeg">

                        <?php

                        $sl = "SELECT DISTINCT(CATEGORY_NAME) FROM category";
                        $r = $conn->query($sl);
                        if ($r->num_rows > 0) {
                          echo "<option value=''>Select Category</option>";
                          while ($ro = $r->fetch_assoc()) {
                            echo "<option value='{$ro["CATEGORY_NAME"]}'>{$ro["CATEGORY_NAME"]}</option>";
                          }
                        }
                        ?>

                      </select>
                      <span class="error">*</span>
                  </tr>
                  </td>
                  <tr>
                    <td>
                      <p>PRODUCT NAME </p>
                    </td>
                  </tr>
                  <tr>
                    <td> <input type="text" name="pname" required pattern="^[a-zA-Z]+(?:[\s.]+[a-zA-Z]+)*$">
                      <span class="error">*</span> </td>
                  </tr>
                  <tr>
                    <td>
                      <p>DESCRIPTION</p>
                    </td>
                  </tr>
                  <tr>
                    <td> <textarea name="descript" rows="10" cols="80"></textarea>

                  
                 
                  <tr>
                    <td>
                      <p>UNIT</p>
                    </td>
                  </tr>

                  <tr>
                    <td>



                      <!--<input type="text" name="unit" required >-->

                      <select name="unit" id="unit" required class="selectdeg">
                        <option value="">Select Unit</option>
                        <option value="Bags">Bags</option>
                        <option value="Bottles">Bottles</option>
                        <option value="Box">Box</option>
                        <option value="Dozens">Dozens</option>
                        <option value="Feet">Feet</option>
                        <option value="Gallon">Gallon</option>
                        <option value="Grams">Grams</option>
                        <option value="Inch">Inch</option>
                        <option value="Kg">Kg</option>
                        <option value="Liters">Liters</option>
                        <option value="Meter">Meter</option>
                        <option value="pcs">Pcs</option>
                        <option value="Packet">Packet</option>
                        <option value="Rolls">Rolls</option>
                      </select>
                      <span class="error">*</span>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <p>UNIT PRICE</p>
                    </td>
                  </tr>
                  <tr>
                    <td> <input type="number" name="unit_price" min=1 max=50000 step=0.01 required>
                      <span class="error">*</span></td>
                  </tr>
                  <tr>
                    <td>
                      <p>IMAGE</p>
                    </td>
                  </tr>
                  <tr>
                    <td> <input type="file" name="image"></td>
                  </tr>

              </div>
              </table>
              <div class="modal-footer">
                <button type="submit" class="btn btn-default" value="submit" name="submit">submit</button>
              </div>
            </form>
          </div>

        </div>
      </div>
    </div>
  </div>






  </br>
  </br>


  <div class="container-fluid">

    <table class="table table-striped">
      <thead>
        <tr class="success">
          <th>PRODUCT ID</th>
          <th>CATEGORY NAME</th>
          <th>PRODUCT NAME</th>
          <th>DESCRIPTION</th>
        
          <th>UNIT</th>
          <th>UNIT PRICE</th>
          <th>IMAGE</th>
          <th>ACTION</th>

        </tr>
      <tbody>
        <?php

        $sql1 = "SELECT * FROM product";
        $result = $conn->query($sql1);

        if ($result->num_rows > 0) {
          // output data of each row


          while ($row = $result->fetch_assoc()) {
            $image_id1 = $row["PRODUCT_ID"];
          

        ?>
            </tr>
      <tbody>
        <tr>
          <td><?php echo '<b style="color:blue;font-weight:bold;">' . $row["PRODUCT_ID"] ?> </td>
          <td><?php echo '<b>' . $row["CATEGORY_NAME"] ?> </td>
          <td><?php echo '<b>' . $row["PRODUCT_NAME"] ?> </td>

          <td><?php echo '<b>' . $row["DESCRIPTION"] ?> </td>

       

          <td><?php echo '<b>' . $row["UNIT"] ?> </td>
          <td><?php echo '<b>' . $row["UNIT_PRICE"] ?> </td>
          <td><img src="img/<?php echo $image_id1;?>.jpg" width="100px" height="100px">
          </td>
          <td><a href="delproduct.php?status_id=<?php echo $row['PRODUCT_ID']; ?>">


              <button type="button" class="btn btn-danger"><span class="glyphicon glyphicon-trash "></span> Delete</button></a>
            <br><br>

            <a href="updatep.php?status_id=<?php echo $row['PRODUCT_ID']; ?>">
              <button type="button" class="btn btn-success" data-toggle="modal" data-target="#myModal1">

                <span class="glyphicon glyphicon-open-file" style="font-weight:bold"></span> Update</button>
            </a></td>
        </tr>




    <?php


          }
        }
        

    ?>
      </tbody>
      </thead>
    </table>

  </div>


</body>
<?php mysqli_close($conn);?>
</html>