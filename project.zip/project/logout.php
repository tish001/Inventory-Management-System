
<?php
	include('connection.php');
	if(isset($_COOKIE['USER_NAME'])) $user = $_COOKIE['USER_NAME'];
	if(isset($_SESSION['USER_NAME'])) $user = $_SESSION['USER_NAME'];
	if(!isset($user))
	{
		echo"<script>window.open('login.php?mes=Access Denied..','_self');</script>";
		
	}

?>
<?php
	$sql = "select * from admin";
	$result = mysqli_query($conn, $sql);
	if ($result->num_rows > 0) {
		while ($row = $result->fetch_assoc()) {
	
$r=$row["USER_NAME"];

		}
	}

session_unset();
session_destroy();
$cookie_name = 'USER_NAME';
	$cookie_value = $r;
	
	setcookie($cookie_name, $cookie_value, time()-60);
	
echo "<script>window.open('login.php','_self');</script>";
?>
    <?php mysqli_close($conn);?>